export class User {
    constructor(
        public name: string,
        public address : string,
        public phone : number,
        public dob : number,
        public email : string,    
    ) {}

}
